<?php
return array(
  'db' => array('host'=>'localhost','name'=>'awrms','user'=>'awrms_user','pass'=>'awrms_pass'),
  'media_dir' => '/var/www/html/awrms/media',
  'icecast' => array('mount'=>'/stream','host'=>'localhost','port'=>8000)
);
